#!/bin/bash

# Create all category pages with header subscribe button and lighter grey nav

declare -a pages=(
  "infrastructure.html|Infrastructure|Network infrastructure, servers, storage, and connectivity"
  "graphics.html|Graphics|Real-time graphics, motion graphics, and visual technology"
  "cloud.html|Cloud Production|Cloud-based production, remote workflows, and SaaS platforms"
  "streaming.html|Streaming|OTT platforms, video delivery, and streaming technology"
  "audio-ai.html|Audio & AI|Audio technology, AI tools, and machine learning"
  "playout.html|Playout|Master control, channel automation, and playout systems"
  "newsroom.html|Newsroom|Newsroom systems, automation, and editorial workflows"
)

for page_info in "${pages[@]}"; do
  IFS='|' read -r filename title description <<< "$page_info"
  category=$(echo "$filename" | sed 's/.html//')
  
  # Determine active link
  active_link=""
  case "$category" in
    "infrastructure") active_link="infrastructure.html" ;;
    "graphics") active_link="graphics.html" ;;
    "cloud") active_link="cloud.html" ;;
    "streaming") active_link="streaming.html" ;;
    "audio-ai") active_link="audio-ai.html" ;;
    "playout") active_link="playout.html" ;;
    "newsroom") active_link="newsroom.html" ;;
  esac

cat > "/mnt/user-data/outputs/TheStreamic-CORRECTED/$filename" << EOFILE
<!DOCTYPE html>
<html lang="en">
<head>
  <!-- Google Consent Mode v2 - Default Denied -->
  <script>
    window.dataLayer = window.dataLayer || [];
    function gtag(){dataLayer.push(arguments);}
    gtag('consent', 'default', {
      'ad_storage': 'denied',
      'ad_user_data': 'denied',
      'ad_personalization': 'denied',
      'analytics_storage': 'denied'
    });
  </script>
  
  <!-- Google AdSense -->
  <script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-8033069131874524" crossorigin="anonymous"></script>
  
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="description" content="$description">
  <meta name="keywords" content="$category, broadcast technology, media infrastructure, professional video">
  <meta name="author" content="The Streamic">
  <link rel="canonical" href="https://www.yoursite.com/$filename">
  <meta property="og:type" content="website">
  <meta property="og:url" content="https://www.yoursite.com/$filename">
  <meta property="og:title" content="$title - The Streamic">
  <meta property="og:description" content="$description">
  <title>$title - The Streamic | Broadcast Technology News</title>
  <link rel="stylesheet" href="style.css">
</head>
<body data-category="$category">
  
  <nav class="site-nav">
    <div class="nav-inner">
      <a href="index.html" class="nav-logo">THE STREAMIC</a>
      <button class="nav-toggle" aria-label="Toggle menu">☰</button>
      <ul class="nav-links">
        <li><a href="featured.html">FEATURED</a></li>
        <li><a href="infrastructure.html" $([ "$active_link" = "infrastructure.html" ] && echo 'class="active"')>INFRASTRUCTURE</a></li>
        <li><a href="graphics.html" $([ "$active_link" = "graphics.html" ] && echo 'class="active"')>GRAPHICS</a></li>
        <li><a href="cloud.html" $([ "$active_link" = "cloud.html" ] && echo 'class="active"')>CLOUD PRODUCTION</a></li>
        <li><a href="streaming.html" $([ "$active_link" = "streaming.html" ] && echo 'class="active"')>STREAMING</a></li>
        <li><a href="audio-ai.html" $([ "$active_link" = "audio-ai.html" ] && echo 'class="active"')>AUDIO & AI</a></li>
        <li><a href="playout.html" $([ "$active_link" = "playout.html" ] && echo 'class="active"')>PLAYOUT</a></li>
      </ul>
      
      <!-- Subscribe Button in Header -->
      <div class="header-subscribe">
        <button onclick="showSubscribeModal()" class="header-subscribe-btn">Subscribe</button>
      </div>
    </div>
  </nav>

  <header class="page-hero">
    <div class="hero-inner">
      <h1 class="category-heading">$title</h1>
      <p>$description</p>
    </div>
  </header>

  <main class="category-content">
    <div id="bentoGridLarge" class="bento-grid-large"></div>
    <div id="listGrid" class="list-grid"></div>
  </main>

  <footer class="site-footer">
    <div class="footer-content">
      <div class="footer-grid">
        <div class="foot-col">
          <h4>About</h4>
          <p>An independent resource for systems architects and media technologists tracking the evolution of broadcast infrastructure.</p>
          <p class="footer-tagline">Real-time insights. Industry-leading coverage.</p>
        </div>
        
        <div class="foot-col">
          <h4>Categories</h4>
          <a href="featured.html">Featured</a>
          <a href="infrastructure.html">Infrastructure</a>
          <a href="graphics.html">Graphics</a>
          <a href="cloud.html">Cloud Production</a>
          <a href="streaming.html">Streaming</a>
          <a href="audio-ai.html">Audio & AI</a>
          <a href="playout.html">Playout</a>
        </div>
        
        <div class="foot-col">
          <h4>Resources</h4>
          <a href="about.html">About Us</a>
          <a href="contact.html">Contact</a>
          <a href="vlog.html">Editor's Desk</a>
          <a href="terms.html">Terms of Service</a>
          <a href="privacy.html">Privacy Policy</a>
          <a href="rss-policy.html">RSS Policy</a>
        </div>
        
        <div class="foot-col">
          <h4>Stay Connected</h4>
          <a href="https://twitter.com/thestreamic" target="_blank" rel="noopener">Twitter</a>
          <a href="https://linkedin.com/company/thestreamic" target="_blank" rel="noopener">LinkedIn</a>
          <a href="mailto:info@thestreamic.in">Email Us</a>
        </div>
      </div>
      
      <div class="footer-bottom">
        <p class="footer-note">© 2026 The Streamic. All rights reserved.</p>
        <p class="footer-tech">Powered by RSS aggregation & smart content curation</p>
      </div>
    </div>
  </footer>

  <!-- Subscribe Modal -->
  <div id="subscribeModal" class="subscribe-modal" style="display: none;">
    <div class="subscribe-modal-overlay" onclick="closeSubscribeModal()"></div>
    <div class="subscribe-modal-content">
      <button class="subscribe-modal-close" onclick="closeSubscribeModal()">&times;</button>
      <h2>Join the Future of Broadcast</h2>
      <p>Get the latest technology insights delivered to your inbox</p>
      <form id="subscribeForm" onsubmit="return handleSubscribe(event)">
        <input 
          type="email" 
          class="subscribe-modal-input" 
          placeholder="Enter your email"
          required
          id="subscribeEmail"
        >
        <button type="submit" class="subscribe-modal-btn">Subscribe</button>
      </form>
      <div id="subscribeSuccess" class="subscribe-success" style="display: none;">
        <p>✓ Welcome to the Future of Broadcast. You are subscribed!</p>
      </div>
    </div>
  </div>

  <!-- Cookie Consent Banner -->
  <div id="cookieConsent" class="cookie-consent" style="display: none;">
    <div class="cookie-consent-content">
      <div class="cookie-text">
        <p>We use cookies to personalize content and ads, and to analyze our traffic. By clicking "Accept", you consent to our use of cookies.</p>
      </div>
      <div class="cookie-buttons">
        <button onclick="declineCookies()" class="cookie-btn cookie-decline">Decline</button>
        <button onclick="acceptCookies()" class="cookie-btn cookie-accept">Accept</button>
      </div>
    </div>
  </div>

  <script>
    // Cookie Consent Functions
    function acceptCookies() {
      gtag('consent', 'update', {
        'ad_storage': 'granted',
        'ad_user_data': 'granted',
        'ad_personalization': 'granted',
        'analytics_storage': 'granted'
      });
      localStorage.setItem('cookieConsent', 'accepted');
      document.getElementById('cookieConsent').style.display = 'none';
    }

    function declineCookies() {
      localStorage.setItem('cookieConsent', 'declined');
      document.getElementById('cookieConsent').style.display = 'none';
    }

    // Show cookie banner if user hasn't made a choice
    window.addEventListener('DOMContentLoaded', function() {
      const consent = localStorage.getItem('cookieConsent');
      if (!consent) {
        document.getElementById('cookieConsent').style.display = 'block';
      } else if (consent === 'accepted') {
        gtag('consent', 'update', {
          'ad_storage': 'granted',
          'ad_user_data': 'granted',
          'ad_personalization': 'granted',
          'analytics_storage': 'granted'
        });
      }
    });

    // Subscribe Modal Functions
    function showSubscribeModal() {
      document.getElementById('subscribeModal').style.display = 'flex';
      document.body.style.overflow = 'hidden';
    }

    function closeSubscribeModal() {
      document.getElementById('subscribeModal').style.display = 'none';
      document.body.style.overflow = 'auto';
    }

    function handleSubscribe(event) {
      event.preventDefault();
      
      const email = document.getElementById('subscribeEmail').value.trim();
      
      if (!email.includes('@') || !email.includes('.')) {
        alert('Please enter a valid email address');
        return false;
      }
      
      const formData = new FormData();
      formData.append('entry.592345898', email);
      
      fetch('https://docs.google.com/forms/d/e/1FAIpQLSdbeoEH4KHqRG7jFWMB4u8cEH27AMPAmPYEuYKtrn9sDewG2A/formResponse', {
        method: 'POST',
        mode: 'no-cors',
        body: formData
      }).then(() => {
        document.getElementById('subscribeForm').style.display = 'none';
        document.getElementById('subscribeSuccess').style.display = 'block';
        setTimeout(closeSubscribeModal, 3000);
      }).catch(() => {
        document.getElementById('subscribeForm').style.display = 'none';
        document.getElementById('subscribeSuccess').style.display = 'block';
        setTimeout(closeSubscribeModal, 3000);
      });
      
      return false;
    }

    // Close modal on ESC key
    document.addEventListener('keydown', function(e) {
      if (e.key === 'Escape') {
        closeSubscribeModal();
      }
    });
  </script>

  <script src="main.js?v=20260209"></script>
</body>
</html>
EOFILE

done

echo "Created all category pages with header subscribe button!"
